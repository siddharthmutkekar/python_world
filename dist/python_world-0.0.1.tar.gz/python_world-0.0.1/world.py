def world():
	return "world"